/*Fall 2019 STSCI 5060 Final Project*/
/*Name: Jingyue Wu */
/*NetID: jw2625 */

SET pagesize 1000
SET linesize 5000
SELECT user FROM Dual;
SELECT Sysdate FROM Dual;
drop table school_finance_2010_t CASCADE CONSTRAINT;
DROP TABLE state_t CASCADE CONSTRAINT;

title'********P2********'skip 2
/*Create a table State_t */
SELECT * FROM State_t;

title'********P3********'skip 2
/* Update State_T table */
UPDATE State_T
set STCODE = '0'||substr(STCODE, 1,1)
WHERE CAST (STCODE AS NUMBER) <10;
SELECT * FROM state_T
WHERE STCODE <10;

title'********P4********'skip 2
/* Connect SAS to oracle database and display the table in Oracle */
DESCRIBE School_Finance_2010_t;
SELECT * FROM School_Finance_2010_t
WHERE ROWNUM <=10;

title'********P5********'skip 2
/* Change the table properties*/ 
ALTER TABLE School_Finance_2010_t
MODIFY (IDCENSUS VARCHAR2(15));
ALTER TABLE School_Finance_2010_t
modify (name VARCHAR2(60));


title'********P6********'skip 2
--Change the column names
ALTER TABLE School_Finance_2010_t
RENAME COLUMN NAME TO SD_NAME;

ALTER TABLE School_Finance_2010_t
RENAME COLUMN STATE TO STCODE;

title'********P7********'skip 2
/*Step 7a */
Drop table Fedrev_t cascade constraints;
CREATE TABLE Fedrev_t AS
SELECT IDCENSUS, STCODE, (c14+c15+c16+c17+c18+c19+c11+c20+c25+c36+b10+b12+b13) AS fed_rev
FROM School_Finance_2010_t;
SELECT*FROM Fedrev_t;
/*Step 7b */
Drop table strev_t cascade constraints;
CREATE TABLE Strev_t AS
SELECT IDCENSUS, STCODE, (c01+c04+c05+c06+c07+c08+c09+c10+c11+c12+c13+c24+c35+c38+c39)  AS st_rev
FROM School_Finance_2010_t;
SELECT*FROM Strev_t;
/*Step 7C */
Drop table locrev_t cascade constraints;
CREATE TABLE locrev_t AS
SELECT IDCENSUS, STCODE, (t02+t06+t09+t15+t40+t99+d11+d23+a07+a08+a09+a11+a13+a15+a20+a40+u11+u22+u30+u50+u97) 
AS loc_rev
FROM School_Finance_2010_t;
SELECT*FROM locrev_t;
/*Step 7d */
drop table school_t cascade constraints;
CREATE TABLE School_t AS
SELECT IDCENSUS, STCODE, SD_NAME
FROM School_Finance_2010_t;
select*from school_t;

title'********P8********'skip 2
/* Step 8a: set stcode as PK of State_t */
ALTER TABLE State_t
ADD CONSTRAINT STATE_PK PRIMARY KEY (stcode);
alter table school_t
add constraint school_pk primary key (idcensus);
/* Step8b: Set idensus as PK of FEDREV_t, STREV_t,LOCREV_t */
ALTER TABLE Fedrev_t
ADD CONSTRAINT FEDREV_PK PRIMARY KEY (IDCENSUS);
ALTER TABLE Strev_t
ADD CONSTRAINT STREV_PK PRIMARY KEY (IDCENSUS);
ALTER TABLE  Locrev_t
ADD CONSTRAINT LOCREV_PK PRIMARY KEY (IDCENSUS);

/* Step8C: Set idensus as FK of FEDREV_t, STREV_t,LOCREV_t that references IDCENSUS of SCHOOL_t */
ALTER TABLE Fedrev_t
ADD CONSTRAINT Fedrev_FK FOREIGN KEY (IDCENSUS) REFERENCES School_t(IDCENSUS);
ALTER TABLE STREV_t
ADD CONSTRAINT STREV_FK FOREIGN KEY (IDCENSUS) REFERENCES School_t(IDCENSUS);
ALTER TABLE LOCREV_t
ADD CONSTRAINT LOCREV_FK FOREIGN KEY (IDCENSUS) REFERENCES School_t(IDCENSUS);
/* Step8D: set STCODE of school_t as FK that references stcode of state_t*/
ALTER TABLE School_t
ADD CONSTRAINT School_FK FOREIGN KEY (STCODE) REFERENCES STATE_t(STCODE);

title'********P10********'skip 2
/* list all school districts that received more than $1,000,000k from federal sources */
drop view school_district_fed;
create view school_districct_fed as
select*from Fedrev_t;
SELECT IDCENSUS, STCODE, to_char(FED_REV *1000,'999999999999.9') AS Fed_revenue
FROM Fedrev_T
WHERE FED_REV > 1000000;
/* list all school districts that received more than $1,000,000k from state sources */
drop view school_district_st;
create view school_districct_st as
select*from Strev_t;
SELECT IDCENSUS, STCODE, to_char(ST_REV *1000,'999999999999.9')  AS st_revenue
FROM Strev_T
WHERE ST_REV > 1000000;
/* list all school districts that received more than $1,000,000k from local sources */
drop view school_district_loc;
create view school_districct_loc as
select*from Locrev_t;
SELECT IDCENSUS, STCODE, to_char(LOC_REV*1000,'999999999999.9')AS loc_revenue
FROM LOCREV_T
WHERE LOC_REV > 1000000;


title'********P11********'skip 2
/*create a view*/
drop view sd#_v;
CREATE view sd#_v AS
SELECT COUNT (IDCENSUS) AS SD#, STCODE
FROM school_finance_2010_t
GROUP BY stcode;
/*11A list the state with highest muber of school district */
SELECT sd#_v.stcode, state_t.stname, sd#
FROM sd#_v, state_t
where sd#_v.stcode=state_t.stcode
and sd#=(select max(sd#) from sd#_v);
/*11B list the state with lowest muber of school district */
SELECT sd#_v.stcode, state_t.stname, sd#
FROM sd#_v, state_t
where sd#_v.stcode=state_t.stcode
and sd#=(select min(sd#) from sd#_v);

title'********P12********'skip 2
/*12a: create 3 views and calculate max revenue */
drop view mfr_v;
CREATE VIEW mfr_v AS
    SELECT stcode, max(fed_rev)AS MAX_FED_REV
    FROM Fedrev_t
    GROUP BY stcode
    ORDER BY stcode;
    
drop view msr_v;
CREATE VIEW msr_v AS
    SELECT stcode, max(st_rev)AS MAX_ST_REV
    FROM strev_t
    GROUP BY stcode
    ORDER BY stcode;
    
drop view mlr_v;
CREATE VIEW mlr_v AS
    SELECT stcode, max(loc_rev)AS MAX_loc_REV
    FROM locrev_t
    GROUP BY stcode
    ORDER BY stcode;

/*12c: create 3 views and calculate max revenue */
select to_char(mfslr_t.stcode,'999999999') as STCODE,
        to_char(max_fed_rev,'999999999.9') as max_fed_rev,
        to_char(max_st_rev,'999999999.9') as max_st_rev,
        to_char(MAX_loc_REV,'999999999.9') as max_loc_rev,
        state_t.stname
FROM mfslr_t, state_t 
where mfslr_t.stcode=state_t.stcode;

title'********P13********'skip 2
/*list the state name,code, highest fed revenue */
select state_t.stname state_name,
    to_char(mfslr_t.stcode,'999999999') as state_code,
    to_char(max_fed_rev,'999999999') as max_fed_rev,
    sd_name
from mfslr_t, state_t, school_finance_2010_t, fedrev_t
where(mfslr_t.stcode=state_t.stcode)
and (mfslr_t.stcode=school_finance_2010_t.stcode)
and (mfslr_t.stcode=fedrev_t.stcode)
and (school_finance_2010_t.idcensus=fedrev_t.idcensus)
and (fedrev_t.fed_rev=max_fed_rev);

title'********P14********'skip 2
/*create a view called total_rev_v */
drop view total_rev_v;
create view total_rev_v as
select fedrev_t.idcensus, fedrev_t.stcode, fedrev_t.fed_rev tfedrev,
        strev_t.st_rev tstrev,
        locrev_t.loc_rev tlocrev
from fedrev_t, strev_t, locrev_t
where (fedrev_t.idcensus=strev_t.idcensus)
and (strev_t.idcensus = locrev_t.idcensus);


title'********P15********'skip 2
/* calculate the total revenues of 3 sources */
select*from
(select total_rev_v.stcode, state_t.stname, total_rev_v.idcensus,
        (tfedrev + tstrev + tlocrev) total_revenue
 from total_rev_v, state_t
 where total_rev_v.stcode=state_t.stcode
 order by total_revenue desc)
 where rownum <= 100;

title'********P16********'skip 2
/*Find out the total school expenditure of each state */
select school_finance_2010_t.stcode, stname, sum(TOTALEXP) total_school_exp_state
from school_finance_2010_t, state_t
where school_finance_2010_t.stcode = state_t.stcode
group by school_finance_2010_t.stcode, stname
ORDER BY total_school_exp_state desc;

title'********P17********'skip 2
/* calculate the total amount of money */
SET HEADING OFF
select 'The total amount that the United States spent on the public school systems in 2010 was' || 
                     to_char(sum(totalexp), '$999999999.9')) 'k.'
from school_finance_2010_t;
SET HEADING ON

title'********P18********'skip 2
/* Create 3 views*/
/* 18A: calculate the federal revenue to each school district */
drop view fed_contribution_v;
CREATE VIEW fed_contribution_v as
select school_finance_2010_t.idcensus, fedrev_t.stcode,state_t.stname, sd_name,
        to_char((fed_rev/totalexp), '999999999.9999') fed_pcnt
from fedrev_t,  school_finance_2010_t, state_t
where state_t.stcode=fedrev_t.stcode
and state_t.stcode =  school_finance_2010_t.stcode
and fedrev_t.idcensus =  school_finance_2010_t.idcensus
and  school_finance_2010_t.totalexp > 0;
select idcensus, stcode, stname, sd_name, fed_pcnt
from fed_contribution_v
where fed_pcnt > 1
order by fed_pcnt desc;
/*18B calculate the state revenue contribution to each school district */
drop view st_contribution_v;
CREATE VIEW st_contribution_v as
select school_finance_2010_t.idcensus, strev_t.stcode,state_t.stname, sd_name,
        to_char((st_rev/totalexp), '999999999.9999') st_pcnt
from strev_t,  school_finance_2010_t, state_t
where state_t.stcode=strev_t.stcode
and state_t.stcode =  school_finance_2010_t.stcode
and strev_t.idcensus =  school_finance_2010_t.idcensus
and  school_finance_2010_t.totalexp > 0;
select idcensus, stcode, stname, sd_name, st_pcnt
from st_contribution_v
where st_pcnt > 1
order by st_pcnt desc;
/*18c calculate the local revenue contribution to each school district */
drop view loc_contribution_v;
CREATE VIEW loc_contribution_v as
select school_finance_2010_t.idcensus, locrev_t.stcode,state_t.stname, sd_name,
        to_char((loc_rev/totalexp), '999999999.9999') loc_pcnt
from locrev_t,  school_finance_2010_t, state_t
where state_t.stcode=locrev_t.stcode
and state_t.stcode =  school_finance_2010_t.stcode
and locrev_t.idcensus =  school_finance_2010_t.idcensus
and  school_finance_2010_t.totalexp > 0;
select idcensus, stcode, stname, sd_name, loc_pcnt
from loc_contribution_v
where loc_pcnt > 1
order by loc_pcnt desc;

title'********P19********'skip 2
/*create another view called fsl_contribution_v */
drop view fsl_contribution_v;
create view fsl_contribution_v as
select fcv.idcensus,fcv.stcode,fcv.sd_name,
        to_char((fcv.fed_pcnt+scv.st_pcnt+lcv.loc_pcnt),'999999999.9999') as fsl_pcnt
from fed_contribution_v fcv
join st_contribution_v scv on fcv.idcensus = scv.idcensus
join loc_contribution_v lcv on lcv.idcensus = fcv.idcensus;
/*19A find out school districts that received total revenues over 3 times of total amount that they spent*/
select fcv.*
from fsl_contribution_v fcv, school_finance_2010_t sf
where fsl_pcnt >3
and fcv.idcensus=sf.idcensus
and fcv.stcode=sf.stcode
order by fsl_pcnt desc;
/*19B find out school districts that received total revenues up to 30% of the total they spent */
select fcv.*
from fsl_contribution_v fcv, school_finance_2010_t sf
where fsl_pcnt <0.3
and fcv.idcensus=sf.idcensus
and fcv.stcode=sf.stcode
order by fsl_pcnt desc;